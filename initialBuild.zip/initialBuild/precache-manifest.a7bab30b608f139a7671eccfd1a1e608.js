self.__precacheManifest = [
  {
    "revision": "abd48d5a751546c9b15b",
    "url": "/static/css/main.a80e9ec3.chunk.css"
  },
  {
    "revision": "abd48d5a751546c9b15b",
    "url": "/static/js/main.b0250cab.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "1aa5ccf424095db6e983",
    "url": "/static/css/2.d34f69dd.chunk.css"
  },
  {
    "revision": "1aa5ccf424095db6e983",
    "url": "/static/js/2.324ecf12.chunk.js"
  },
  {
    "revision": "6f422c3e8628a10a1bf10b0efcdec6b9",
    "url": "/index.html"
  }
];